/**
 * Simple mock API server for development without Docker/Python
 * Run with: node mock-api.js
 */
const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = 8000;

// Load scenario data
const scenariosDir = path.join(__dirname, 'apps', 'api', 'seed');
const scenarios = [];

try {
    const files = ['uae_real_estate.json', 'uae_local_services.json', 'uae_ecommerce.json'];
    for (const file of files) {
        const data = JSON.parse(fs.readFileSync(path.join(scenariosDir, file), 'utf8'));
        scenarios.push(data);
    }
} catch (e) {
    console.error('Failed to load scenarios:', e.message);
}

// In-memory storage for MVP
const accounts = [];
const campaigns = [];
const runs = [];
const dailyResults = [];

// CORS headers
const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, PATCH, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Content-Type': 'application/json',
};

// UUID generator
function uuid() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
        const r = Math.random() * 16 | 0;
        const v = c === 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    });
}

// Parse JSON body
async function parseBody(req) {
    return new Promise((resolve, reject) => {
        let body = '';
        req.on('data', chunk => body += chunk);
        req.on('end', () => {
            try {
                resolve(body ? JSON.parse(body) : {});
            } catch (e) {
                resolve({});
            }
        });
        req.on('error', reject);
    });
}

// Route handler
async function handleRequest(req, res) {
    const url = new URL(req.url, `http://localhost:${PORT}`);
    const method = req.method;
    const path = url.pathname;

    // Handle CORS preflight
    if (method === 'OPTIONS') {
        res.writeHead(204, corsHeaders);
        res.end();
        return;
    }

    // Health check
    if (path === '/health' && method === 'GET') {
        res.writeHead(200, corsHeaders);
        res.end(JSON.stringify({
            status: 'healthy',
            service: 'adsim-api-mock',
            version: '0.1.0',
            timestamp: new Date().toISOString(),
        }));
        return;
    }

    // Scenarios list
    if (path === '/scenarios' && method === 'GET') {
        res.writeHead(200, corsHeaders);
        res.end(JSON.stringify({
            scenarios: scenarios.map(s => ({
                slug: s.slug,
                name: s.name,
                market: s.market,
                description: s.description,
            })),
            count: scenarios.length,
        }));
        return;
    }

    // Scenario detail
    const scenarioMatch = path.match(/^\/scenarios\/([^/]+)$/);
    if (scenarioMatch && method === 'GET') {
        const slug = scenarioMatch[1];
        const scenario = scenarios.find(s => s.slug === slug);
        if (scenario) {
            res.writeHead(200, corsHeaders);
            res.end(JSON.stringify(scenario));
        } else {
            res.writeHead(404, corsHeaders);
            res.end(JSON.stringify({ detail: 'Scenario not found' }));
        }
        return;
    }

    // Mock login
    if (path === '/auth/mock-login' && method === 'POST') {
        const body = await parseBody(req);
        const email = body.email || 'demo@example.com';
        res.writeHead(200, corsHeaders);
        res.end(JSON.stringify({
            access_token: 'mock_token_' + Date.now(),
            token_type: 'bearer',
            expires_in: 86400,
            user: {
                id: '00000000-0000-0000-0000-000000000001',
                email: email,
                name: email.split('@')[0],
            },
        }));
        return;
    }

    // Accounts list
    if (path === '/accounts' && method === 'GET') {
        res.writeHead(200, corsHeaders);
        res.end(JSON.stringify({ accounts, count: accounts.length }));
        return;
    }

    // Create account
    if (path === '/accounts' && method === 'POST') {
        const body = await parseBody(req);
        const account = {
            id: uuid(),
            name: body.name || 'New Account',
            daily_budget: body.daily_budget || 100,
            currency: body.currency || 'USD',
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
        };
        accounts.push(account);
        res.writeHead(201, corsHeaders);
        res.end(JSON.stringify(account));
        return;
    }

    // Account detail
    const accountMatch = path.match(/^\/accounts\/([^/]+)$/);
    if (accountMatch && method === 'GET') {
        const id = accountMatch[1];
        const account = accounts.find(a => a.id === id);
        if (account) {
            res.writeHead(200, corsHeaders);
            res.end(JSON.stringify(account));
        } else {
            res.writeHead(404, corsHeaders);
            res.end(JSON.stringify({ detail: 'Account not found' }));
        }
        return;
    }

    // Campaigns for account
    const campaignsMatch = path.match(/^\/accounts\/([^/]+)\/campaigns$/);
    if (campaignsMatch && method === 'GET') {
        const accountId = campaignsMatch[1];
        const accountCampaigns = campaigns.filter(c => c.sim_account_id === accountId);
        res.writeHead(200, corsHeaders);
        res.end(JSON.stringify({ campaigns: accountCampaigns, count: accountCampaigns.length }));
        return;
    }

    if (campaignsMatch && method === 'POST') {
        const accountId = campaignsMatch[1];
        const body = await parseBody(req);
        const campaign = {
            id: uuid(),
            sim_account_id: accountId,
            name: body.name || 'New Campaign',
            status: body.status || 'draft',
            budget: body.budget || 50,
            bid_strategy: body.bid_strategy || 'manual_cpc',
            target_cpa: body.target_cpa || null,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
        };
        campaigns.push(campaign);
        res.writeHead(201, corsHeaders);
        res.end(JSON.stringify(campaign));
        return;
    }

    // Runs for account
    const runsMatch = path.match(/^\/accounts\/([^/]+)\/runs$/);
    if (runsMatch && method === 'GET') {
        const accountId = runsMatch[1];
        const accountRuns = runs.filter(r => r.sim_account_id === accountId);
        res.writeHead(200, corsHeaders);
        res.end(JSON.stringify({ runs: accountRuns, count: accountRuns.length }));
        return;
    }

    if (runsMatch && method === 'POST') {
        const accountId = runsMatch[1];
        const body = await parseBody(req);
        const run = {
            id: uuid(),
            sim_account_id: accountId,
            scenario_id: body.scenario_slug || 'uae-real-estate',
            rng_seed: body.seed || Math.floor(Math.random() * 2147483647),
            duration_days: body.duration_days || 30,
            current_day: 0,
            status: 'pending',
            started_at: null,
            completed_at: null,
            created_at: new Date().toISOString(),
        };
        runs.push(run);
        res.writeHead(201, corsHeaders);
        res.end(JSON.stringify(run));
        return;
    }

    // Simulate day
    const simulateMatch = path.match(/^\/runs\/([^/]+)\/simulate-day$/);
    if (simulateMatch && method === 'POST') {
        const runId = simulateMatch[1];
        const run = runs.find(r => r.id === runId);
        if (!run) {
            res.writeHead(404, corsHeaders);
            res.end(JSON.stringify({ detail: 'Run not found' }));
            return;
        }

        // Simulate a day with mock data
        run.current_day += 1;
        if (run.status === 'pending') {
            run.status = 'running';
            run.started_at = new Date().toISOString();
        }

        const rng = run.rng_seed + run.current_day;
        const rand = (n) => ((rng * n * 9301 + 49297) % 233280) / 233280;

        const result = {
            id: uuid(),
            run_id: runId,
            day_number: run.current_day,
            impressions: Math.floor(500 + rand(1) * 2000),
            clicks: Math.floor(20 + rand(2) * 100),
            conversions: Math.floor(1 + rand(3) * 15),
            cost: Math.round((50 + rand(4) * 150) * 100) / 100,
            revenue: Math.round((20 + rand(5) * 300) * 100) / 100,
            avg_position: Math.round((1 + rand(6) * 3) * 10) / 10,
            avg_quality_score: Math.round((0.4 + rand(7) * 0.4) * 100) / 100,
            impression_share: Math.round((0.5 + rand(8) * 0.4) * 100) / 100,
            lost_is_budget: Math.round(rand(9) * 0.3 * 100) / 100,
            lost_is_rank: Math.round(rand(10) * 0.3 * 100) / 100,
            created_at: new Date().toISOString(),
        };
        dailyResults.push(result);

        if (run.current_day >= run.duration_days) {
            run.status = 'completed';
            run.completed_at = new Date().toISOString();
        }

        res.writeHead(200, corsHeaders);
        res.end(JSON.stringify({
            status: 'success',
            day: run.current_day,
            ...result,
        }));
        return;
    }

    // Run results
    const resultsMatch = path.match(/^\/runs\/([^/]+)\/results$/);
    if (resultsMatch && method === 'GET') {
        const runId = resultsMatch[1];
        const run = runs.find(r => r.id === runId);
        if (!run) {
            res.writeHead(404, corsHeaders);
            res.end(JSON.stringify({ detail: 'Run not found' }));
            return;
        }

        const runResults = dailyResults.filter(r => r.run_id === runId).sort((a, b) => a.day_number - b.day_number);

        let totals = null;
        if (runResults.length > 0) {
            totals = {
                day_number: 0,
                impressions: runResults.reduce((s, r) => s + r.impressions, 0),
                clicks: runResults.reduce((s, r) => s + r.clicks, 0),
                conversions: runResults.reduce((s, r) => s + r.conversions, 0),
                cost: runResults.reduce((s, r) => s + r.cost, 0),
                revenue: runResults.reduce((s, r) => s + r.revenue, 0),
                avg_position: runResults.reduce((s, r) => s + r.avg_position, 0) / runResults.length,
                avg_quality_score: runResults.reduce((s, r) => s + r.avg_quality_score, 0) / runResults.length,
                impression_share: runResults.reduce((s, r) => s + r.impression_share, 0) / runResults.length,
                lost_is_budget: runResults.reduce((s, r) => s + r.lost_is_budget, 0) / runResults.length,
                lost_is_rank: runResults.reduce((s, r) => s + r.lost_is_rank, 0) / runResults.length,
            };
            totals.ctr = totals.clicks / totals.impressions;
            totals.cvr = totals.conversions / totals.clicks;
            totals.cpc = totals.cost / totals.clicks;
            totals.cpa = totals.cost / totals.conversions;
            totals.roas = totals.revenue / totals.cost;
        }

        res.writeHead(200, corsHeaders);
        res.end(JSON.stringify({
            run_id: runId,
            status: run.status,
            current_day: run.current_day,
            duration_days: run.duration_days,
            daily_results: runResults.map(r => ({
                ...r,
                ctr: r.clicks / r.impressions,
                cvr: r.conversions / r.clicks,
                cpc: r.cost / r.clicks,
                cpa: r.cost / r.conversions,
                roas: r.revenue / r.cost,
            })),
            totals,
        }));
        return;
    }

    // 404 fallback
    res.writeHead(404, corsHeaders);
    res.end(JSON.stringify({ detail: 'Not found', path, method }));
}

// Start server
const server = http.createServer(async (req, res) => {
    try {
        await handleRequest(req, res);
    } catch (err) {
        console.error('Error:', err);
        res.writeHead(500, corsHeaders);
        res.end(JSON.stringify({ detail: 'Internal server error' }));
    }
});

server.listen(PORT, () => {
    console.log(`\n🚀 AdSim Lab Mock API running at http://localhost:${PORT}`);
    console.log(`📚 Scenarios loaded: ${scenarios.length}`);
    console.log(`\nEndpoints:`);
    console.log(`  GET  /health`);
    console.log(`  GET  /scenarios`);
    console.log(`  POST /auth/mock-login`);
    console.log(`  GET  /accounts`);
    console.log(`  POST /accounts`);
    console.log(`  GET  /accounts/:id/campaigns`);
    console.log(`  POST /accounts/:id/campaigns`);
    console.log(`  GET  /accounts/:id/runs`);
    console.log(`  POST /accounts/:id/runs`);
    console.log(`  POST /runs/:id/simulate-day`);
    console.log(`  GET  /runs/:id/results`);
    console.log(`\nPress Ctrl+C to stop\n`);
});
